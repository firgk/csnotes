import{be as t}from"./index-3f268199.js";function r(){return t({url:"/about"})}export{r as g};
