import{be as t}from"./index-1352e314.js";function r(){return t({url:"/about"})}export{r as g};
